//naufaldy_bambang_Dqd0
/*Goal tahun ini:
1. Belajar JavaScript.
2. Menjadi Front-End atau Back-End Developer.
*/