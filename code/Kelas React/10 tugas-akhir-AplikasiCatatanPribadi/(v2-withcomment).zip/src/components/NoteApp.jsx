import React from "react";
import NoteAppHeader from "./NoteAppHeader";
import NoteAppBody from "./NoteAppBody";
import { getInitialData } from "../utils/index";

class NoteApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            notes: JSON.parse(localStorage.getItem('notes')) || getInitialData(),
            searchKey: "", // Menambahkan state untuk pencarian
            toastMessages: [], // Menambahkan state untuk pesan toast
        };
        this.onSearchEventHandler = this.onSearchEventHandler.bind(this);
        this.onDeleteEventHandler = this.onDeleteEventHandler.bind(this);
        this.onAddEventHandler = this.onAddEventHandler.bind(this);
        this.onMoveEventHandler = this.onMoveEventHandler.bind(this);
        this.showToast = this.showToast.bind(this); // Binding fungsi toast
    }

    // Fungsi untuk menampilkan toast
    showToast(message) {
        this.setState((prevState) => ({
            toastMessages: [message],
        }));

        // Menghapus toast setelah 3 detik
        setTimeout(() => {
            this.setState((prevState) => ({
                toastMessages: [],
            }));
        }, 3000);
    }

    onSearchEventHandler(searchKey) {
        this.setState({ searchKey }); // Update searchKey
    }

    onDeleteEventHandler(id) {
        const notes = this.state.notes.filter((note) => note.id !== id);
        this.setState({ notes }, () => {
            localStorage.setItem('notes', JSON.stringify(this.state.notes));
            this.showToast("Catatan berhasil dihapus!"); // Menampilkan toast setelah delete
        });
    }

    onMoveEventHandler(id) {
        const updatedNotes = this.state.notes.map((note) => {
            if (note.id === id) {
                return { ...note, archived: !note.archived }; 
            }
            return note;
        });

        this.setState({ notes: updatedNotes }, () => {
            localStorage.setItem('notes', JSON.stringify(this.state.notes));
            this.showToast("Catatan berhasil dipindahkan!"); // Menampilkan toast setelah pindah
        });
    }

    onAddEventHandler({ title, body, archived }) {
        this.setState((prevState) => {
            const updatedNotes = [
                    ...prevState.notes,
                    {
                        id: +new Date(),
                        title,
                        body,
                        createdAt: new Date(),
                        archived,
                    }
                ];
            localStorage.setItem('notes', JSON.stringify(updatedNotes));
            this.showToast("Catatan berhasil ditambahkan!"); // Menampilkan toast setelah tambah
            return { notes: updatedNotes };
        });
    }

    render() {
        return(
            <div className="note-app">
                {/* Toast messages */}
                <div className="toast-container">
                    {this.state.toastMessages.map((message, index) => (
                        <div key={index} className="toast">
                            {message}
                        </div>
                    ))}
                </div>

                <NoteAppHeader
                    searchKey={this.state.searchKey}
                    onSearch={this.onSearchEventHandler} // Passing callback
                />
                <NoteAppBody 
                    onAdd={this.onAddEventHandler} 
                    notes={this.state.notes} 
                    onDelete={this.onDeleteEventHandler} 
                    onMove={this.onMoveEventHandler} 
                    searchKey={this.state.searchKey} // Pass searchKey ke NoteAppBody
                />
            </div>
        );
    }
}

export default NoteApp;
