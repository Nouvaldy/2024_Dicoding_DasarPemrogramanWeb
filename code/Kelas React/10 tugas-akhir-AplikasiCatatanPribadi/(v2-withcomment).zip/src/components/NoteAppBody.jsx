import React from "react";
import NoteInput from "./NoteInput";
import NotesList from "./NotesList";

function NoteAppBody({ onAdd, notes, onDelete, onMove, searchKey }) {
    return(
        <div className="note-app__body">
            <NoteInput onAdd={onAdd} />
            <NotesList notes={notes} onDelete={onDelete} onMove={onMove} searchKey={searchKey} />
        </div>
    )
}

export default NoteAppBody;