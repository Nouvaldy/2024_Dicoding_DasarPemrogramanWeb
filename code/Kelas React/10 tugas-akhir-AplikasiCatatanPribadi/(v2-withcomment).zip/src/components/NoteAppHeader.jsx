import React from "react";

class NoteAppHeader extends React.Component {
    constructor(props) {
        super(props);
        this.onSearchChangeEventHandler = this.onSearchChangeEventHandler.bind(this);
    }

    // Event handler untuk menangani perubahan input pencarian
    onSearchChangeEventHandler(event) {
        this.props.onSearch(event.target.value); // Panggil fungsi callback dari parent
    }

    render() {
        return (
            <div className="note-app__header">
                <h1>Notes</h1>
                <div className="note-search">
                    <input 
                        type="text" 
                        id="search" 
                        placeholder="Cari catatan ..." 
                        value={this.props.searchKey} 
                        onChange={this.onSearchChangeEventHandler} 
                    />
                </div>
            </div>
        );
    }
}

export default NoteAppHeader;
