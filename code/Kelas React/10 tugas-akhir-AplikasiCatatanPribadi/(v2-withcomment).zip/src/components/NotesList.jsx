import React from "react";
import NoteItem from "./NoteItem";

function NotesList({ notes, onDelete, onMove, searchKey }) {
    // Memisahkan catatan berdasarkan status archived
    const activeNotes = notes.filter((note) => !note.archived); // notes yang belum diarsipkan
    const archivedNotes = notes.filter((note) => note.archived); // notes yang sudah diarsipkan

    // Fungsi untuk menyaring catatan berdasarkan pencarian
    const filterNotes = (notesList) => {
        if (!searchKey) return notesList; // Jika tidak ada pencarian, kembalikan semua catatan
        return notesList.filter((note) =>
            note.title.toLowerCase().includes(searchKey.toLowerCase()) || // Mencari di judul
            note.body.toLowerCase().includes(searchKey.toLowerCase())   // Mencari di isi catatan
        );
    }

    // Menyaring catatan aktif dan arsip berdasarkan pencarian
    const filteredActiveNotes = filterNotes(activeNotes);
    const filteredArchivedNotes = filterNotes(archivedNotes);

    return (
        <>
            <h2>Catatan Aktif</h2>
            <div className="notes-list">
                {filteredActiveNotes.length === 0 ? (
                    <p className="notes-list__empty-message">Tidak ada catatan</p>
                ) : (
                    filteredActiveNotes.map((note) => (
                        <NoteItem
                            {...note}
                            onDelete={onDelete}
                            onMove={onMove}
                            key={note.id}
                        />
                    ))
                )}
            </div>

            <h2>Arsip</h2>
            <div className="notes-list">
                {filteredArchivedNotes.length === 0 ? (
                    <p className="notes-list__empty-message">Tidak ada catatan arsip</p>
                ) : (
                    filteredArchivedNotes.map((note) => (
                        <NoteItem
                            {...note}
                            onDelete={onDelete}
                            onMove={onMove}
                            key={note.id}
                        />
                    ))
                )}
            </div>
        </>
    );
}

export default NotesList;
